@extends('layout/main-light')

@section('title', 'pricing')

@section('container')
<div class="container">
<div class="row">
<div class="col-10">
<h1 class="mt-10">Laravel - {{$nama}}</h1>
</div>
</div>
</div>
@endsection